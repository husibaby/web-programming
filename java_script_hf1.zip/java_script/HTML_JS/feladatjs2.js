lista=[0,7,16,30,41];
console.log(lista);