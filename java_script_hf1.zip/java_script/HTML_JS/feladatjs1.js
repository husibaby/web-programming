a=15;
b=12;
c=a+b;
console.log(a);
console.log(b);
console.log(c);